//
//  ColorScrollerApp.swift
//  ColorScroller
//
//  Created by Jenica on 2/4/26.
//

import SwiftUI

@main
struct ColorScrollerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
